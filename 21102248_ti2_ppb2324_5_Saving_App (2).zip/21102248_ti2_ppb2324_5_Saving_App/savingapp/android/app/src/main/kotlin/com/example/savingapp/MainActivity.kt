package com.example.savingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
